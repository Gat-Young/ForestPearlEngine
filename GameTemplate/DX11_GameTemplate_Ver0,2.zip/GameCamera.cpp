#include "GameCamera.h"
#include "ForestPearlEngine/CameraComponent.h"
#include "ForestPearlEngine/FPAController.h"
#include "ForestPearlEngine/FPWorld.h"
#include "ForestPearlEngine/GameTimer.h"
#include "ForestPearlEngine/Object/Components/InputComponent.h"
#include "ForestPearlEngine/InputValue.h"
#include "ForestPearlEngine/Utility/FPGameplayStatics.h"
#include <iostream>

void GameCamera::Initialize()
{
	Target = new FPSceneComponent(this);
	SetRootComponent(Target);
	SetActorLocation({ 0.0f, 0.0f, -0.0f });

	Camera = new CameraComponent(this);

	Camera->SetupAttachment(Target);
	Camera->SetRelativeLocation({ 0.0f, 20.0f, -45.0f });

	FPAController* Controller = GetWorld()->GetController(0);

	if (Controller == nullptr)
		return;

	Controller->GetInputComponent().BindMethod("IA_SetMoveCamera", this, EKeyState::Pressed, &GameCamera::Move);

	CameraRotation = FPQuaternion{ 0.0f, 0.0f, 0.0f, 1.0f };


}

void GameCamera::BeginPlay()
{
}

void GameCamera::Tick()
{
	FPActor* player = FPGameplayStatics::GetActorOfClass(GetWorld(), "Triangle");

	if (player != nullptr)
	{
		SetActorLocation(player->GetActorLocation());
		Camera->LookAt = Target->GetComponentLocation();
	}
	__super::Tick();
}

void GameCamera::Move(FInputValue value)
{
	//std::cout << "CameraMove [ " << Camera->GetComponentRotation().x << " : " << Camera->GetComponentRotation().y << " : " << Camera->GetComponentRotation().z << " ]\n";
	std::cout << "CameraMove [ " << GetActorRotation().x << " : " << GetActorRotation().y << " : " << GetActorRotation().z << " ]\n";
	float mov = 30.0f;
	float move_x = value.X * mov * (GetWorld()->GetGameTimer()->DeltaTime());
	float move_y = value.Y * mov * (GetWorld()->GetGameTimer()->DeltaTime());

	FPQuaternion PitchRotation = AngleAxis(DegToRad(move_y), FPVector3{ 1.0f, 0.0f, 0.0f });
	FPQuaternion YawRotation = AngleAxis(DegToRad(-move_x), FPVector3{ 0.0f, 1.0f, 0.0f });

	//���� x�� ȸ��
	CameraRotation = (CameraRotation * PitchRotation).Normalize();

	//���� y�� ȸ��
	CameraRotation = (YawRotation * CameraRotation).Normalize();
	Camera->Up = Rotate(CameraRotation, FPVector3{ 0, 1, 0 });


	RootComponent->SetWorldRotation(CameraRotation.ToEuler());
}